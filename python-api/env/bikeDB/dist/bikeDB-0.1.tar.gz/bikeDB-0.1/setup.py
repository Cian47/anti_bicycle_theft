from distutils.core import setup

setup(
	name = 'bikeDB',
	version = '0.1',
	py_modules = ['bikeDB'],
	author = 'Martin Schwarzmaier',
	author_email = "martin.schwarzmaier@gmail.com",
	url = 'localhost :-)',
	description = 'A MongoDB wrapper for the BikeTheftApp'
)